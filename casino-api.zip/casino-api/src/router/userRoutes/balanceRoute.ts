import { Router } from "express";

const router = Router();

//Define routes Here


export default router;